const { gs } = require( '@shining3d/app/dist/utils/http' );
class CloseWatch {
	constructor ( options ) {
		console.log( '插件执行了，关闭监听程序' );
	}

	apply ( compiler ) {
		compiler.hooks.afterResolvers.tap( 'CloseWatch', ( compiler ) => {
			console.log( '...end...' );
			gs.stop();
		});
	}
}
module.exports = CloseWatch;
