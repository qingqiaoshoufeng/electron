const path = require( 'path' );
let App;

const isElectron = process.argv[ 3 ];
if ( isElectron && isElectron.indexOf( 'electron' ) > -1 ){
	App = require( '@shining3d/electronapp' ).default;
} else {
	App = require( '@shining3d/app' ).default;
}

const isDevelopment = process.env.NODE_ENV === 'development';

const app = new App({ staticPath: path.resolve( __dirname, './public' ) });

module.exports = ( api ) => {
	if ( isDevelopment ) {
		api.registerCommand( 'serve:async', async ( args ) => {
			// 初始化ETCD
			await app.install({ name: 'etcd' });
			await api.service.run( 'serve', args );
		});
	}
};

module.exports.defaultModes = { 'serve:async': 'development' };

module.exports.app = app;
