const config = require( 'config' );
const createProxyMiddleware = require( 'http-proxy-middleware' ).createProxyMiddleware;
const Logger = require( '@shining3d/logger' ).default;
function proxyMiddlewareOther( req, res, next ) {
	return createProxyMiddleware({
		target: res.locals.baseURL,
		headers: { 'X-Source': config.get( 'name' ) },
		pathRewrite: { '^/other/': '/' },
		changeOrigin: true,
		secure: false,
		preserveHeaderKeyCase: true,
		xfwd: true,
		onError( e ) {
			Logger.error( '网关代理失败', e );
		}
	})( req, res, next );
}

module.exports.proxyMiddlewareOther = proxyMiddlewareOther;
