module.exports = {
	port: 8080,
	host: '0.0.0.0',
	name: 'dentalCloud2.0',
	debug: false,
	logger: {
		level: 'verbose',
		silent: false
	},
	auth: { secret: 'shiningapp' },
	session: {},
	sign: { expire: 30_000 }
};
