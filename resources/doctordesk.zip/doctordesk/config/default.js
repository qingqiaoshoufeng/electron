module.exports = {
	name: 'productCloud2.0',
	port: 3000,
	host: '0.0.0.0',
	debug: false,
	logger: {
		level: 'verbose',
		silent: false
	},
	auth: { secret: 'shiningapp' },
	session: {},
	sign: { expire: 30_000 }
};
