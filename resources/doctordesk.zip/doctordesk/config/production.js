module.exports = {
	debug: false,
	port: 8080,
	logger: {
		level: 'verbose',
		silent: false
	}
};
