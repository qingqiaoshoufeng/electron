
const path = require( 'path' );
const fs = require( 'fs-extra' );
const envCode = process.argv[ 2 ];
const rootPath = process.cwd();
const envJsonPath = path.join( rootPath, 'server.env.json' );
const envInfo = fs.readJSONSync( envJsonPath );

const jsonPath = path.join( rootPath, '/electron_dist/server.conf.json' );
let serverConfig = fs.readJSONSync( jsonPath );

serverConfig.global.cdnUrl = envInfo[ envCode ].cdn;
serverConfig.pub.cdnUrl = envInfo[ envCode ].cdn;
serverConfig.global.currentCdnUrl = envInfo[ envCode ].currentCdnUrl;
serverConfig.env.mode = envInfo[ envCode ].mode;
serverConfig.env.defaultCdnUrl = envInfo[ envCode ].currentCdnUrl;


const proConfig = envInfo[ envCode ].api;
serverConfig.api = proConfig
fs.writeFileSync( jsonPath, JSON.stringify( serverConfig ));

Object.keys( proConfig ).forEach(( e ) => {
	if ( proConfig[ e ] && proConfig[ e ].appID ){
		proConfig[ e ].appID = '###appid';
	}
});

const backupServerConfPath = path.join( rootPath, '/electron_dist/server.conf.backup.json' );
serverConfig.api = proConfig;
fs.writeFileSync( backupServerConfPath, JSON.stringify( serverConfig ));
