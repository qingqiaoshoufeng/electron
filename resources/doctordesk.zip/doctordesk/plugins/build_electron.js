// Check if the main bundles are built

const path = require( 'path' );
const fs = require( 'fs' );
const rimraf = require( 'rimraf' );
const chalk = require( 'chalk' );
const copydir = require( 'copy-dir' );

const electronDistPath = path.resolve( './electron_dist' );
const electronAppjsPath = path.resolve( './app.js' );
const serverConfPath = path.resolve( './server.conf.json' );

if ( !fs.existsSync( electronDistPath )) {
	fs.mkdirSync( electronDistPath );
} else {
	try {
		rimraf.sync( electronDistPath );
		fs.mkdirSync( electronDistPath );
	} catch ( error ) {
		throw new Error( chalk.whiteBright.bgRed.bold( '清理electron dist path 失败' ));
	}
}

// copy electron_app.js到electron_dist目录下
copydir.sync( electronAppjsPath, `${electronDistPath}/app.js` );

// copy config 到 electron_dist目录下
copydir.sync( path.resolve( './config' ), `${path.resolve( './electron_dist' )}/config` );

// copy plugins 到 electron_dist目录下
copydir.sync( path.resolve( './plugins' ), `${path.resolve( './electron_dist' )}/plugins` );

// copy plugins 到 electron_dist目录下
copydir.sync( path.resolve( './package.json' ), `${path.resolve( './electron_dist' )}/package.json` );

// copy dist到electron_dist目录下
copydir.sync( path.resolve( './dist' ), `${path.resolve( './electron_dist' )}/dist` );

// copy server.conf到electron_dist目录下
copydir.sync( path.resolve( serverConfPath ), `${path.resolve( './electron_dist' )}/server.conf.json` );


// 添加翻译及global配置到server.conf
// try {
// 	const serverConf = JSON.parse( fs.readFileSync( serverConfPath, 'utf-8' ));
// 	let environment = fs.readFileSync( path.resolve( './public/dev/environment.js' ), 'utf-8' );
// 	environment = JSON.parse( environment.replace( 'window.app = ', '' ));
// 	serverConf.en_US = Object.assign( serverConf.en_US, environment.etcdConfig.en_US );
// 	serverConf.ja_JP = Object.assign( serverConf.ja_JP, environment.etcdConfig.ja_JP );
// 	serverConf.zh_CN = Object.assign( serverConf.zh_CN, environment.etcdConfig.zh_CN );
// 	serverConf.global = environment.global;
// 	fs.writeFileSync( `${electronDistPath}/server.conf.json`, JSON.stringify( serverConf ));
// 	console.log( 'electron project build done' );
// } catch ( error ) {
// 	throw new Error( chalk.whiteBright.bgRed.bold( 'electron 打包 配置server.conf翻译失败' ));
// }
