const path = require( 'path' );
const App = require( '@shining3d/electronapp' ).default;
const isDevelopment = process.env.NODE_ENV === 'development';

const app = new App({ staticPath: path.resolve( __dirname, './public' ) });

module.exports = ( api ) => {
	if ( isDevelopment ) {
		api.registerCommand( 'serve:async', async ( args ) => {
			// 初始化ETCD
			await app.install({ name: 'server' });
			await api.service.run( 'serve', args );
		});
	}
};

module.exports.defaultModes = { 'serve:async': 'development' };

module.exports.app = app;
