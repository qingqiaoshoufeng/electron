const path = require( 'path' );
const App = require( '@shining3d/electronapp' ).default;
const express = require( 'express' );
const cookieParser = require( 'cookie-parser' );
( async function (){
	const app = new App({
		staticPath: path.resolve( __dirname, './dist' ),
		staticPrefix: '/statics'
	});

	await app.install({ name: 'server' });
	app.use( express.json());
	app.use( express.urlencoded({ extended: false }));
	app.use( cookieParser());
	app.setMiddlewares([
		{ name: 'proxy' },
		{ name: 'uuid' },
		{ name: 'lang' },
		{ name: 'matomo' },
		{ name: 'serverConfig' }
	]);

	app.start();
})();
